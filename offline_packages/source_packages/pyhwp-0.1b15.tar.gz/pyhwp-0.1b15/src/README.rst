``pyhwp/`` - the main source code
---------------------------------

``hwp5/``
   The main source package. For now, there is not much documentation about the
   source code.
